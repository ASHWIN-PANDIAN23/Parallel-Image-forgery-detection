# Configuration for image forgery detection
INPUT_DIR = "data/input"
OUTPUT_DIR = "data/output"
