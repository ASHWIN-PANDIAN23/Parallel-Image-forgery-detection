#!/bin/bash
mpirun -n 4 python3 forgery_mpi.py
